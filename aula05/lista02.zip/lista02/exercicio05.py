is_vazio = True
is_preenchido = not is_vazio

print("is_vazio = ", is_vazio)
print("is_preenchido = ", is_preenchido)