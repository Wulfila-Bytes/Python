resultado = 13 % 7
print("O resultado da divisão entre 13 e 7 é:", resultado)