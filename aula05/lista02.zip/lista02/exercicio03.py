hora_valor = float(input("Digite o quanto você ganha por hora: "))
horas_mes = float(input("Digite quantas horas trabalha em um mês: "))

salario = hora_valor * horas_mes
print("Seu salário mênsal é de: R$", salario)