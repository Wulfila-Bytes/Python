variavel_inteira = int(input("Digite um valor: "))

print("Antecessor: ", variavel_inteira - 1)
print("Sucessor: ", variavel_inteira + 1)