a = float(input("Digite um número"))
b = float(input("Digite um outro número"))

print("Subtração: ", a - b)
print("Soma: ", a + b)
print("Multiplicação: ", a * b)
print("Divisão: ", a % b)