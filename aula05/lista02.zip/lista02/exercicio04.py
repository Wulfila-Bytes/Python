media = 6.3
possui_presenca = True

elegivel_bolsa = media >= 7.0 and possui_presenca
print("Elegível para bolsa de estudos?", elegivel_bolsa)