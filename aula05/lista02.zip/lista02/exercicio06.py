total_cliques = 0
total_cliques += 1
print(f'O total de cliques e de: {total_cliques}')
total_cliques += 1
print(f'O total de cliques e de: {total_cliques}')