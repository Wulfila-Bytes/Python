km_percorridos = float(input("Quantos quilômetros já foram pecorridos? "))
dias_aluguel = int(input("Por quantos dias o carro foi alugado? "))

preco = (dias_aluguel * 60) + (km_percorridos * 0.15)
print("O preço final é: R$", preco)